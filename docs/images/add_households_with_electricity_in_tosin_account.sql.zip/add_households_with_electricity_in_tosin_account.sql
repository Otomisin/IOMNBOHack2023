USE ROLE ACCOUNTADMIN;
USE WAREHOUSE COMPUTE_WH;

SET db_name = 'iom_hackathon_data_shared'; ----<<<<<<<<<<<<<<<<<< if necessary change the name of the db here
SET raw_schema_name = 'raw';
SET dimensional_schema_name = 'dimensional';

USE DATABASE identifier($db_name);
USE SCHEMA identifier($raw_schema_name);

-- create new stage in raw schema to upload data
CREATE STAGE IF NOT EXISTS new_datasets
DIRECTORY = (ENABLE = TRUE)
FILE_FORMAT = (TYPE = 'CSV')
; 

--***********************************************************************************************
-->>>>>>>>>>>>>> UPLOAD DATA TO THE STAGE VIA SNOWSIGHT UI BEFORE CONTINUING <<<<<<<<<<<<<<<<<<<
--***********************************************************************************************


-- create households_with_electricity table

CREATE OR REPLACE TABLE HOUSEHOLDS_WITH_ELECTRICITY (
	DATA_VARIABLE VARCHAR(16777216),
	ADMIN_0_NAMES VARCHAR(16777216) COMMENT 'Name of the Country',
	ADMIN_0_PCODE VARCHAR(16777216) COMMENT 'Country Code',
	ADMIN_1_NAMES VARCHAR(16777216) COMMENT 'Name of the largest sub-national division',
	ADMIN_1_PCODE VARCHAR(16777216) COMMENT 'Postal Code of the largest sub-national division',
	ISO3 VARCHAR(16777216) COMMENT 'ISO3 Country Code',
	ISO2 VARCHAR(16777216) COMMENT 'ISO2 Country Code',
	LONGITUDE FLOAT COMMENT 'Longitude of the Centroid of the ADMIN_1 region',
	LATITUDE FLOAT COMMENT 'Latitude of the Centroid of the ADMIN_1 region',
	Y2000 FLOAT,
    Y2001 FLOAT,
	Y2002 FLOAT,
	Y2003 FLOAT,
	Y2004 FLOAT,
	Y2005 FLOAT,
	Y2006 FLOAT,
	Y2007 FLOAT,
	Y2008 FLOAT,
	Y2009 FLOAT,
	Y2010 FLOAT,
	Y2011 FLOAT,
	Y2012 FLOAT,
	Y2013 FLOAT,
	Y2014 FLOAT,
	Y2015 FLOAT,
	Y2016 FLOAT,
	Y2017 FLOAT,
	Y2018 FLOAT,
	Y2019 FLOAT,
	Y2020 FLOAT,
    Y2021 FLOAT,
    Y2022 FLOAT
)
;

-- load data from the internal stage to the table

INSERT INTO HOUSEHOLDS_WITH_ELECTRICITY
(
SELECT 
    'Households_with_electricity' AS DATA_VARIABLE, 
    $3 AS ADMIN_0_NAMES, 
    $6 AS ADMIN_0_PCODE, 
    $5 AS ADMIN_1_NAMES, 
    $4 AS ADMIN_1_PCODE, 
    $6 AS ISO3,
    $7 AS ISO2,
    $9 AS LONGITUDE, 
    $8 AS LATITUDE,
    $10 AS Y2000,
    $11 AS Y2001,
	$12 AS Y2002,
	$13 AS Y2003,
	$14 AS Y2004,
	$15 AS Y2005,
	$16 AS Y2006,
	$17 AS Y2007,
	$18 AS Y2008,
	$19 AS Y2009,
	$20 AS Y2010,
	$21 AS Y2011,
	$22 AS Y2012,
	$23 AS Y2013,
	$24 AS Y2014,
	$25 AS Y2015,
	$26 AS Y2016,
	$27 AS Y2017,
	$28 AS Y2018,
	$29 AS Y2019,
	$30 AS Y2020,
    $31 AS Y2021,
    $32 AS Y2022
FROM 
    @new_datasets/GDL_datasets.csv 
WHERE 
    $3<>'ADM0_EN' --skip header
)
;

SELECT * FROM HOUSEHOLDS_WITH_ELECTRICITY;

--add households with electricity and rebuild the dimensional schema

USE SCHEMA identifier($dimensional_schema_name);

SET admin_1_info = CONCAT($db_name,'.',$raw_schema_name,'.','admin_1_info');
SET agesex_female0to19 = CONCAT($db_name,'.',$raw_schema_name,'.','agesex_female0to19');
SET agesex_female20to64 = CONCAT($db_name,'.',$raw_schema_name,'.','agesex_female20to64');
SET agesex_female65p = CONCAT($db_name,'.',$raw_schema_name,'.','agesex_female65p');
SET agesex_male0to19 = CONCAT($db_name,'.',$raw_schema_name,'.','agesex_male0to19');
SET agesex_male20to64 = CONCAT($db_name,'.',$raw_schema_name,'.','agesex_male20to64');
SET agesex_male65p = CONCAT($db_name,'.',$raw_schema_name,'.','agesex_male65p');
SET climate_aridity = CONCAT($db_name,'.',$raw_schema_name,'.','climate_aridity');
SET climate_avgtmp = CONCAT($db_name,'.',$raw_schema_name,'.','climate_avgtmp');
SET climate_maxpre = CONCAT($db_name,'.',$raw_schema_name,'.','climate_maxpre');
SET climate_maxtmp = CONCAT($db_name,'.',$raw_schema_name,'.','climate_maxtmp');
SET climate_minpre = CONCAT($db_name,'.',$raw_schema_name,'.','climate_minpre');
SET climate_mintmp = CONCAT($db_name,'.',$raw_schema_name,'.','climate_mintmp');
SET climate_totpre = CONCAT($db_name,'.',$raw_schema_name,'.','climate_totpre');
SET climate_totwet = CONCAT($db_name,'.',$raw_schema_name,'.','climate_totwet');
SET foodinsecurity_avg = CONCAT($db_name,'.',$raw_schema_name,'.','foodinsecurity_avg');
SET hazardrisk_cropfailure = CONCAT($db_name,'.',$raw_schema_name,'.','hazardrisk_cropfailure');
SET hazardrisk_drought = CONCAT($db_name,'.',$raw_schema_name,'.','hazardrisk_drought');
SET hazardrisk_heatwave = CONCAT($db_name,'.',$raw_schema_name,'.','hazardrisk_heatwave');
SET hazardrisk_riverflood = CONCAT($db_name,'.',$raw_schema_name,'.','hazardrisk_riverflood');
SET hazardrisk_tropicalcyclone = CONCAT($db_name,'.',$raw_schema_name,'.','hazardrisk_tropicalcyclone');
SET hazardrisk_wildfire = CONCAT($db_name,'.',$raw_schema_name,'.','hazardrisk_wildfire');
SET landuse_builtup = CONCAT($db_name,'.',$raw_schema_name,'.','landuse_builtup');
SET landuse_cropland = CONCAT($db_name,'.',$raw_schema_name,'.','landuse_cropland');
SET landuse_pasture = CONCAT($db_name,'.',$raw_schema_name,'.','landuse_pasture');
SET landuse_rangeland = CONCAT($db_name,'.',$raw_schema_name,'.','landuse_rangeland');
SET socioeconomic_hdi = CONCAT($db_name,'.',$raw_schema_name,'.','socioeconomic_hdi');
SET socioeconomic_netmig = CONCAT($db_name,'.',$raw_schema_name,'.','socioeconomic_netmig');
SET socioeconomic_pcgdp = CONCAT($db_name,'.',$raw_schema_name,'.','socioeconomic_pcgdp');
SET socioeconomic_pop = CONCAT($db_name,'.',$raw_schema_name,'.','socioeconomic_pop');
SET households_with_electricity = CONCAT($db_name,'.',$raw_schema_name,'.','households_with_electricity');

-- reload key_value

TRUNCATE TABLE key_value;

INSERT INTO key_value (
    year,
    country_name,
    sub_region_code,
    sub_region_name,
    metric,
    value
)
WITH SocioEconomic_netmig AS (
    SELECT 
        SUBSTR(year, 2, 4)::integer AS year_int,
        admin_0_names AS country_name,
        admin_1_pcode AS sub_region_code,
        admin_1_names AS sub_region_name,
        data_variable AS metric,
        value
    FROM 
        identifier($socioeconomic_netmig)
        UNPIVOT(value FOR year IN (y2001, y2002,y2003, y2004, y2005, y2006, y2007, y2008, y2009, y2010, y2011, y2012, y2013, y2014, y2015, y2016, y2017, y2018, y2019, y2020))
),
SocioEconomic_pop AS (
    SELECT 
        SUBSTR(year, 2, 4)::integer AS year_int,
        admin_0_names AS country_name,
        admin_1_pcode AS sub_region_code,
        admin_1_names AS sub_region_name,
        data_variable AS metric,
        value
    FROM 
        identifier($socioeconomic_pop)
        UNPIVOT(value FOR year IN (y2001, y2002,y2003, y2004, y2005, y2006, y2007, y2008, y2009, y2010, y2011, y2012, y2013, y2014, y2015, y2016, y2017, y2018, y2019, y2020))
),
SocioEconomic_pcgdp AS (
    SELECT 
        SUBSTR(year, 2, 4)::integer AS year_int,
        admin_0_names AS country_name,
        admin_1_pcode AS sub_region_code,
        admin_1_names AS sub_region_name,
        data_variable AS metric,
        value
    FROM 
        identifier($socioeconomic_pcgdp)
        UNPIVOT(value FOR year IN (y2001, y2002,y2003, y2004, y2005, y2006, y2007, y2008, y2009, y2010, y2011, y2012, y2013, y2014, y2015, y2016, y2017, y2018, y2019, y2020))
),
SocioEconomic_hdi AS (
    SELECT 
        SUBSTR(year, 2, 4)::integer AS year_int,
        admin_0_names AS country_name,
        admin_1_pcode AS sub_region_code,
        admin_1_names AS sub_region_name,
        data_variable AS metric,
        value
    FROM 
        identifier($socioeconomic_hdi)
        UNPIVOT(value FOR year IN (y2001, y2002,y2003, y2004, y2005, y2006, y2007, y2008, y2009, y2010, y2011, y2012, y2013, y2014, y2015, y2016, y2017, y2018, y2019, y2020))
),
AgeSex_female0to19 AS (
    SELECT 
        SUBSTR(year, 2, 4)::integer AS year_int,
        admin_0_names AS country_name,
        admin_1_pcode AS sub_region_code,
        admin_1_names AS sub_region_name,
        data_variable AS metric,
        value
    FROM 
        identifier($agesex_female0to19)
        UNPIVOT(value FOR year IN (y2001, y2002,y2003, y2004, y2005, y2006, y2007, y2008, y2009, y2010, y2011, y2012, y2013, y2014, y2015, y2016, y2017, y2018, y2019, y2020))
),
AgeSex_female20to64 AS (
    SELECT 
        SUBSTR(year, 2, 4)::integer AS year_int,
        admin_0_names AS country_name,
        admin_1_pcode AS sub_region_code,
        admin_1_names AS sub_region_name,
        data_variable AS metric,
        value
    FROM 
        identifier($agesex_female20to64)
        UNPIVOT(value FOR year IN (y2001, y2002,y2003, y2004, y2005, y2006, y2007, y2008, y2009, y2010, y2011, y2012, y2013, y2014, y2015, y2016, y2017, y2018, y2019, y2020))
),
AgeSex_female65p AS (
    SELECT 
        SUBSTR(year, 2, 4)::integer AS year_int,
        admin_0_names AS country_name,
        admin_1_pcode AS sub_region_code,
        admin_1_names AS sub_region_name,
        data_variable AS metric,
        value
    FROM 
        identifier($agesex_female65p)
        UNPIVOT(value FOR year IN (y2001, y2002,y2003, y2004, y2005, y2006, y2007, y2008, y2009, y2010, y2011, y2012, y2013, y2014, y2015, y2016, y2017, y2018, y2019, y2020))
),
AgeSex_male0to19 AS (
    SELECT 
        SUBSTR(year, 2, 4)::integer AS year_int,
        admin_0_names AS country_name,
        admin_1_pcode AS sub_region_code,
        admin_1_names AS sub_region_name,
        data_variable AS metric,
        value
    FROM 
        identifier($agesex_male0to19)
        UNPIVOT(value FOR year IN (y2001, y2002,y2003, y2004, y2005, y2006, y2007, y2008, y2009, y2010, y2011, y2012, y2013, y2014, y2015, y2016, y2017, y2018, y2019, y2020))
),
AgeSex_male20to64 AS (
    SELECT 
        SUBSTR(year, 2, 4)::integer AS year_int,
        admin_0_names AS country_name,
        admin_1_pcode AS sub_region_code,
        admin_1_names AS sub_region_name,
        data_variable AS metric,
        value
    FROM 
        identifier($agesex_male20to64)
        UNPIVOT(value FOR year IN (y2001, y2002,y2003, y2004, y2005, y2006, y2007, y2008, y2009, y2010, y2011, y2012, y2013, y2014, y2015, y2016, y2017, y2018, y2019, y2020))
),
AgeSex_male65p AS (
    SELECT 
        SUBSTR(year, 2, 4)::integer AS year_int,
        admin_0_names AS country_name,
        admin_1_pcode AS sub_region_code,
        admin_1_names AS sub_region_name,
        data_variable AS metric,
        value
    FROM 
        identifier($agesex_male65p)
        UNPIVOT(value FOR year IN (y2001, y2002,y2003, y2004, y2005, y2006, y2007, y2008, y2009, y2010, y2011, y2012, y2013, y2014, y2015, y2016, y2017, y2018, y2019, y2020))
),
Climate_maxtmp AS (
    SELECT 
        SUBSTR(year, 2, 4)::integer AS year_int,
        admin_0_names AS country_name,
        admin_1_pcode AS sub_region_code,
        admin_1_names AS sub_region_name,
        data_variable AS metric,
        value
    FROM 
        identifier($climate_maxtmp)
        UNPIVOT(value FOR year IN (y2001, y2002,y2003, y2004, y2005, y2006, y2007, y2008, y2009, y2010, y2011, y2012, y2013, y2014, y2015, y2016, y2017, y2018, y2019, y2020))
),
Climate_mintmp AS (
    SELECT 
        SUBSTR(year, 2, 4)::integer AS year_int,
        admin_0_names AS country_name,
        admin_1_pcode AS sub_region_code,
        admin_1_names AS sub_region_name,
        data_variable AS metric,
        value
    FROM 
        identifier($climate_mintmp)
        UNPIVOT(value FOR year IN (y2001, y2002,y2003, y2004, y2005, y2006, y2007, y2008, y2009, y2010, y2011, y2012, y2013, y2014, y2015, y2016, y2017, y2018, y2019, y2020))
),
Climate_avgtmp AS (
    SELECT 
        SUBSTR(year, 2, 4)::integer AS year_int,
        admin_0_names AS country_name,
        admin_1_pcode AS sub_region_code,
        admin_1_names AS sub_region_name,
        data_variable AS metric,
        value
    FROM 
        identifier($climate_avgtmp)
        UNPIVOT(value FOR year IN (y2001, y2002,y2003, y2004, y2005, y2006, y2007, y2008, y2009, y2010, y2011, y2012, y2013, y2014, y2015, y2016, y2017, y2018, y2019, y2020))
),
Climate_minpre AS (
    SELECT 
        SUBSTR(year, 2, 4)::integer AS year_int,
        admin_0_names AS country_name,
        admin_1_pcode AS sub_region_code,
        admin_1_names AS sub_region_name,
        data_variable AS metric,
        value
    FROM 
        identifier($climate_minpre)
        UNPIVOT(value FOR year IN (y2001, y2002,y2003, y2004, y2005, y2006, y2007, y2008, y2009, y2010, y2011, y2012, y2013, y2014, y2015, y2016, y2017, y2018, y2019, y2020))
),
Climate_maxpre AS (
    SELECT 
        SUBSTR(year, 2, 4)::integer AS year_int,
        admin_0_names AS country_name,
        admin_1_pcode AS sub_region_code,
        admin_1_names AS sub_region_name,
        data_variable AS metric,
        value
    FROM 
        identifier($climate_maxpre)
        UNPIVOT(value FOR year IN (y2001, y2002,y2003, y2004, y2005, y2006, y2007, y2008, y2009, y2010, y2011, y2012, y2013, y2014, y2015, y2016, y2017, y2018, y2019, y2020))
),
Climate_totpre AS (
    SELECT 
        SUBSTR(year, 2, 4)::integer AS year_int,
        admin_0_names AS country_name,
        admin_1_pcode AS sub_region_code,
        admin_1_names AS sub_region_name,
        data_variable AS metric,
        value
    FROM 
        identifier($climate_totpre)
        UNPIVOT(value FOR year IN (y2001, y2002,y2003, y2004, y2005, y2006, y2007, y2008, y2009, y2010, y2011, y2012, y2013, y2014, y2015, y2016, y2017, y2018, y2019, y2020))
),
Climate_totwet AS (
    SELECT 
        SUBSTR(year, 2, 4)::integer AS year_int,
        admin_0_names AS country_name,
        admin_1_pcode AS sub_region_code,
        admin_1_names AS sub_region_name,
        data_variable AS metric,
        value 
    FROM 
        identifier($climate_totwet)
        UNPIVOT(value FOR year IN (y2001, y2002,y2003, y2004, y2005, y2006, y2007, y2008, y2009, y2010, y2011, y2012, y2013, y2014, y2015, y2016, y2017, y2018, y2019, y2020))
),
Climate_aridity AS (
    SELECT 
        SUBSTR(year, 2, 4)::integer AS year_int,
        admin_0_names AS country_name,
        admin_1_pcode AS sub_region_code,
        admin_1_names AS sub_region_name,
        data_variable AS metric,
        value 
    FROM 
        identifier($climate_aridity)
        UNPIVOT(value FOR year IN (y2001, y2002,y2003, y2004, y2005, y2006, y2007, y2008, y2009, y2010, y2011, y2012, y2013, y2014, y2015, y2016, y2017, y2018, y2019, y2020))
),
FoodInsecurity_avg AS (
    SELECT 
        SUBSTR(year, 2, 4)::integer AS year_int,
        admin_0_names AS country_name,
        admin_1_pcode AS sub_region_code,
        admin_1_names AS sub_region_name,
        data_variable AS metric,
        value
    FROM 
        identifier($foodinsecurity_avg)
        UNPIVOT(value FOR year IN (y2001, y2002,y2003, y2004, y2005, y2006, y2007, y2008, y2009, y2010, y2011, y2012, y2013, y2014, y2015, y2016, y2017, y2018, y2019, y2020))
),
HazardRisk_heatwave AS (
    SELECT 
        SUBSTR(year, 2, 4)::integer AS year_int,
        admin_0_names AS country_name,
        admin_1_pcode AS sub_region_code,
        admin_1_names AS sub_region_name,
        data_variable AS metric,
        value
    FROM 
        identifier($hazardrisk_heatwave)
        UNPIVOT(value FOR year IN (y2001, y2002,y2003, y2004, y2005, y2006, y2007, y2008, y2009, y2010, y2011, y2012, y2013, y2014, y2015, y2016, y2017, y2018, y2019, y2020))
),
HazardRisk_wildfire AS (
    SELECT 
        SUBSTR(year, 2, 4)::integer AS year_int,
        admin_0_names AS country_name,
        admin_1_pcode AS sub_region_code,
        admin_1_names AS sub_region_name,
        data_variable AS metric,
        value
    FROM 
        identifier($hazardrisk_wildfire)
        UNPIVOT(value FOR year IN (y2001, y2002,y2003, y2004, y2005, y2006, y2007, y2008, y2009, y2010, y2011, y2012, y2013, y2014, y2015, y2016, y2017, y2018, y2019, y2020))
),
HazardRisk_drought AS (
    SELECT 
        SUBSTR(year, 2, 4)::integer AS year_int,
        admin_0_names AS country_name,
        admin_1_pcode AS sub_region_code,
        admin_1_names AS sub_region_name,
        data_variable AS metric,
        value
    FROM 
        identifier($hazardrisk_drought)
        UNPIVOT(value FOR year IN (y2001, y2002,y2003, y2004, y2005, y2006, y2007, y2008, y2009, y2010, y2011, y2012, y2013, y2014, y2015, y2016, y2017, y2018, y2019, y2020))
),
HazardRisk_riverflood AS (
    SELECT 
        SUBSTR(year, 2, 4)::integer AS year_int,
        admin_0_names AS country_name,
        admin_1_pcode AS sub_region_code,
        admin_1_names AS sub_region_name,
        data_variable AS metric,
        value
    FROM 
        identifier($hazardrisk_riverflood)
        UNPIVOT(value FOR year IN (y2001, y2002,y2003, y2004, y2005, y2006, y2007, y2008, y2009, y2010, y2011, y2012, y2013, y2014, y2015, y2016, y2017, y2018, y2019, y2020))
),
HazardRisk_tropicalcyclone AS (
    SELECT 
        SUBSTR(year, 2, 4)::integer AS year_int,
        admin_0_names AS country_name,
        admin_1_pcode AS sub_region_code,
        admin_1_names AS sub_region_name,
        data_variable AS metric,
        value
    FROM 
        identifier($hazardrisk_tropicalcyclone)
        UNPIVOT(value FOR year IN (y2001, y2002,y2003, y2004, y2005, y2006, y2007, y2008, y2009, y2010, y2011, y2012, y2013, y2014, y2015, y2016, y2017, y2018, y2019, y2020))
),
HazardRisk_cropfailure AS (
    SELECT 
        SUBSTR(year, 2, 4)::integer AS year_int,
        admin_0_names AS country_name,
        admin_1_pcode AS sub_region_code,
        admin_1_names AS sub_region_name,
        data_variable AS metric,
        value
    FROM 
        identifier($hazardrisk_cropfailure)
        UNPIVOT(value FOR year IN (y2001, y2002,y2003, y2004, y2005, y2006, y2007, y2008, y2009, y2010, y2011, y2012, y2013, y2014, y2015, y2016, y2017, y2018, y2019, y2020))
),
LandUse_cropland AS (
    SELECT 
        SUBSTR(year, 2, 4)::integer AS year_int,
        admin_0_names AS country_name,
        admin_1_pcode AS sub_region_code,
        admin_1_names AS sub_region_name,
        data_variable AS metric,
        value
    FROM 
        identifier($landuse_cropland)
        UNPIVOT(value FOR year IN (y2001, y2002,y2003, y2004, y2005, y2006, y2007, y2008, y2009, y2010, y2011, y2012, y2013, y2014, y2015, y2016, y2017, y2018, y2019, y2020))
),
LandUse_pasture AS (
    SELECT 
        SUBSTR(year, 2, 4)::integer AS year_int,
        admin_0_names AS country_name,
        admin_1_pcode AS sub_region_code,
        admin_1_names AS sub_region_name,
        data_variable AS metric,
        value
    FROM 
        identifier($landuse_pasture)
        UNPIVOT(value FOR year IN (y2001, y2002,y2003, y2004, y2005, y2006, y2007, y2008, y2009, y2010, y2011, y2012, y2013, y2014, y2015, y2016, y2017, y2018, y2019, y2020))
),
LandUse_rangeland AS (
    SELECT 
        SUBSTR(year, 2, 4)::integer AS year_int,
        admin_0_names AS country_name,
        admin_1_pcode AS sub_region_code,
        admin_1_names AS sub_region_name,
        data_variable AS metric,
        value
    FROM 
        identifier($landuse_rangeland)
        UNPIVOT(value FOR year IN (y2001, y2002,y2003, y2004, y2005, y2006, y2007, y2008, y2009, y2010, y2011, y2012, y2013, y2014, y2015, y2016, y2017, y2018, y2019, y2020))
),
LandUse_builtup AS (
    SELECT 
        SUBSTR(year, 2, 4)::integer AS year_int,
        admin_0_names AS country_name,
        admin_1_pcode AS sub_region_code,
        admin_1_names AS sub_region_name,
        data_variable AS metric,
        value
    FROM 
        identifier($landuse_builtup)
        UNPIVOT(value FOR year IN (y2001, y2002,y2003, y2004, y2005, y2006, y2007, y2008, y2009, y2010, y2011, y2012, y2013, y2014, y2015, y2016, y2017, y2018, y2019, y2020))
),
Households_with_electricity AS (
    SELECT 
        SUBSTR(year, 2, 4)::integer AS year_int,
        admin_0_names AS country_name,
        admin_1_pcode AS sub_region_code,
        admin_1_names AS sub_region_name,
        data_variable AS metric,
        value
    FROM 
        identifier($households_with_electricity)
        UNPIVOT(value FOR year IN (y2000, y2001, y2002,y2003, y2004, y2005, y2006, y2007, y2008, y2009, y2010, y2011, y2012, y2013, y2014, y2015, y2016, y2017, y2018, y2019, y2020, y2021, y2022))
),
CTE_combined AS (
    SELECT year_int, country_name, sub_region_code, sub_region_name, metric, value FROM SocioEconomic_netmig
    UNION ALL
    SELECT year_int, country_name, sub_region_code, sub_region_name, metric, value FROM SocioEconomic_pop
    UNION ALL
    SELECT year_int, country_name, sub_region_code, sub_region_name, metric, value  FROM SocioEconomic_pcgdp
    UNION ALL
    SELECT year_int, country_name, sub_region_code, sub_region_name, metric, value  FROM SocioEconomic_hdi
    UNION ALL
    SELECT year_int, country_name, sub_region_code, sub_region_name, metric, value  FROM AgeSex_female0to19
    UNION ALL
    SELECT year_int, country_name, sub_region_code, sub_region_name, metric, value  FROM AgeSex_female20to64
    UNION ALL
    SELECT year_int, country_name, sub_region_code, sub_region_name, metric, value  FROM AgeSex_female65p
    UNION ALL
    SELECT year_int, country_name, sub_region_code, sub_region_name, metric, value  FROM AgeSex_male0to19
    UNION ALL
    SELECT year_int, country_name, sub_region_code, sub_region_name, metric, value  FROM AgeSex_male20to64
    UNION ALL
    SELECT year_int, country_name, sub_region_code, sub_region_name, metric, value  FROM AgeSex_male65p
    UNION ALL
    SELECT year_int, country_name, sub_region_code, sub_region_name, metric, value  FROM Climate_maxtmp
    UNION ALL
    SELECT year_int, country_name, sub_region_code, sub_region_name, metric, value  FROM Climate_mintmp
    UNION ALL
    SELECT year_int, country_name, sub_region_code, sub_region_name, metric, value  FROM Climate_avgtmp
    UNION ALL
    SELECT year_int, country_name, sub_region_code, sub_region_name, metric, value  FROM Climate_minpre
    UNION ALL
    SELECT year_int, country_name, sub_region_code, sub_region_name, metric, value  FROM Climate_maxpre
    UNION ALL
    SELECT year_int, country_name, sub_region_code, sub_region_name, metric, value  FROM Climate_totpre
    UNION ALL
    SELECT year_int, country_name, sub_region_code, sub_region_name, metric, value  FROM Climate_totwet
    UNION ALL
    SELECT year_int, country_name, sub_region_code, sub_region_name, metric, value  FROM Climate_aridity
    UNION ALL
    SELECT year_int, country_name, sub_region_code, sub_region_name, metric, value  FROM FoodInsecurity_avg
    UNION ALL
    SELECT year_int, country_name, sub_region_code, sub_region_name, metric, value  FROM HazardRisk_heatwave
    UNION ALL
    SELECT year_int, country_name, sub_region_code, sub_region_name, metric, value  FROM HazardRisk_wildfire
    UNION ALL
    SELECT year_int, country_name, sub_region_code, sub_region_name, metric, value  FROM HazardRisk_drought
    UNION ALL
    SELECT year_int, country_name, sub_region_code, sub_region_name, metric, value  FROM HazardRisk_riverflood
    UNION ALL
    SELECT year_int, country_name, sub_region_code, sub_region_name, metric, value  FROM HazardRisk_tropicalcyclone
    UNION ALL
    SELECT year_int, country_name, sub_region_code, sub_region_name, metric, value  FROM HazardRisk_cropfailure
    UNION ALL
    SELECT year_int, country_name, sub_region_code, sub_region_name, metric, value  FROM LandUse_cropland
    UNION ALL
    SELECT year_int, country_name, sub_region_code, sub_region_name, metric, value  FROM LandUse_pasture
    UNION ALL
    SELECT year_int, country_name, sub_region_code, sub_region_name, metric, value  FROM LandUse_rangeland
    UNION ALL
    SELECT year_int, country_name, sub_region_code, sub_region_name, metric, value  FROM LandUse_builtup
    UNION ALL
    SELECT year_int, country_name, sub_region_code, sub_region_name, metric, value  FROM Households_with_electricity
)
SELECT 
    year_int AS year,
    country_name,
    sub_region_code,
    sub_region_name,
    metric,
    value
FROM 
    CTE_combined;

--add new dates to dim_time
TRUNCATE TABLE dim_time;

INSERT INTO dim_time (year) VALUES
(2000),
(2001),
(2002),
(2003),
(2004),
(2005),
(2006),
(2007),
(2008),
(2009),
(2010),
(2011),
(2012),
(2013),
(2014),
(2015),
(2016),
(2017),
(2018),
(2019),
(2020),
(2021),
(2022);

-- add households_with_electricity and reload fact_metrics

TRUNCATE TABLE fact_metrics;

ALTER TABLE fact_metrics ADD COLUMN IF NOT EXISTS Households_with_electricity FLOAT;

DESCRIBE TABLE fact_metrics;

INSERT INTO fact_metrics (
    id_dim_time, 
    id_dim_location,
    SocioEconomic_netmig,
    SocioEconomic_pop,
    SocioEconomic_pcgdp,
    SocioEconomic_hdi,
    AgeSex_female0to19,
    AgeSex_female20to64,
    AgeSex_female65p,
    AgeSex_male0to19,
    AgeSex_male20to64,
    AgeSex_male65p,
    Climate_maxtmp,
    Climate_mintmp,
    Climate_avgtmp,
    Climate_minpre,
    Climate_maxpre,
    Climate_totpre,
    Climate_totwet,
    Climate_aridity,
    FoodInsecurity_avg,
    HazardRisk_heatwave,
    HazardRisk_wildfire,
    HazardRisk_drought,
    HazardRisk_riverflood,
    HazardRisk_tropicalcyclone,
    HazardRisk_cropfailure,
    LandUse_cropland,
    LandUse_pasture,
    LandUse_rangeland,
    LandUse_builtup,
    Households_with_electricity
)   
SELECT
    dim_time.id_dim_time AS id_dim_time,
    dim_location.id_dim_location AS id_dim_location,
    MAX(CASE WHEN key_value.metric='SocioEconomic_netmig' THEN key_value.value END) AS SocioEconomic_netmig,
    MAX(CASE WHEN key_value.metric='SocioEconomic_pop' THEN key_value.value END) AS SocioEconomic_pop,
    MAX(CASE WHEN key_value.metric='SocioEconomic_pcgdp' THEN key_value.value END) AS SocioEconomic_pcgdp,
    MAX(CASE WHEN key_value.metric='SocioEconomic_hdi' THEN key_value.value END) AS SocioEconomic_hdi,
    MAX(CASE WHEN key_value.metric='AgeSex_female0to19' THEN key_value.value END) AS AgeSex_female0to19,
    MAX(CASE WHEN key_value.metric='AgeSex_female20to64' THEN key_value.value END) AS AgeSex_female20to64,
    MAX(CASE WHEN key_value.metric='AgeSex_female65p' THEN key_value.value END) AS AgeSex_female65p,
    MAX(CASE WHEN key_value.metric='AgeSex_male0to19' THEN key_value.value END) AS AgeSex_male0to19,
    MAX(CASE WHEN key_value.metric='AgeSex_male20to64' THEN key_value.value END) AS AgeSex_male20to64,
    MAX(CASE WHEN key_value.metric='AgeSex_male65p' THEN key_value.value END) AS AgeSex_male65p,
    MAX(CASE WHEN key_value.metric='Climate_maxtmp' THEN key_value.value END) AS Climate_maxtmp,
    MAX(CASE WHEN key_value.metric='Climate_mintmp' THEN key_value.value END) AS Climate_mintmp,
    MAX(CASE WHEN key_value.metric='Climate_avgtmp' THEN key_value.value END) AS Climate_avgtmp,
    MAX(CASE WHEN key_value.metric='Climate_minpre' THEN key_value.value END) AS Climate_minpre,
    MAX(CASE WHEN key_value.metric='Climate_maxpre' THEN key_value.value END) AS Climate_maxpre,
    MAX(CASE WHEN key_value.metric='Climate_totpre' THEN key_value.value END) AS Climate_totpre,
    MAX(CASE WHEN key_value.metric='Climate_totwet' THEN key_value.value END) AS Climate_totwet,
    MAX(CASE WHEN key_value.metric='Climate_aridity' THEN key_value.value END) AS Climate_aridity,
    MAX(CASE WHEN key_value.metric='FoodInsecurity_avg' THEN key_value.value END) AS FoodInsecurity_avg,
    MAX(CASE WHEN key_value.metric='HazardRisk_heatwave' THEN key_value.value END) AS HazardRisk_heatwave,
    MAX(CASE WHEN key_value.metric='HazardRisk_wildfire' THEN key_value.value END) AS HazardRisk_wildfire,
    MAX(CASE WHEN key_value.metric='HazardRisk_drought' THEN key_value.value END) AS HazardRisk_drought,
    MAX(CASE WHEN key_value.metric='HazardRisk_riverflood' THEN key_value.value END) AS HazardRisk_riverflood,
    MAX(CASE WHEN key_value.metric='HazardRisk_tropicalcyclone' THEN key_value.value END) AS HazardRisk_tropicalcyclone,
    MAX(CASE WHEN key_value.metric='HazardRisk_cropfailure' THEN key_value.value END) AS HazardRisk_cropfailure,
    MAX(CASE WHEN key_value.metric='LandUse_cropland' THEN key_value.value END) AS LandUse_cropland,
    MAX(CASE WHEN key_value.metric='LandUse_pasture' THEN key_value.value END) AS LandUse_pasture,
    MAX(CASE WHEN key_value.metric='LandUse_rangeland' THEN key_value.value END) AS LandUse_rangeland,
    MAX(CASE WHEN key_value.metric='LandUse_builtup' THEN key_value.value END) AS LandUse_builtup,
    MAX(CASE WHEN key_value.metric='Households_with_electricity' THEN key_value.value END) AS Households_with_electricity
FROM
    key_value
        LEFT JOIN dim_time ON key_value.year = dim_time.year
        LEFT JOIN dim_location ON key_value.country_name = dim_location.country_name AND key_value.sub_region_code = dim_location.sub_region_code    
GROUP BY
    id_dim_time,
    id_dim_location
ORDER BY
    id_dim_time,
    id_dim_location
;

--add households_with_electricity and reload combined_data

TRUNCATE TABLE combined_data;

ALTER TABLE combined_data ADD COLUMN IF NOT EXISTS Households_with_electricity FLOAT;
ALTER TABLE combined_data MODIFY COLUMN Households_with_electricity COMMENT 'Description: Households with electricity';

DESC TABLE combined_data;

INSERT INTO combined_data  
SELECT
    dim_time.year,
    dim_location.* exclude (id_dim_location),
    fact_metrics.* exclude (id_fact, id_dim_time, id_dim_location)
FROM 
    fact_metrics
        LEFT JOIN dim_time ON fact_metrics.id_dim_time = dim_time.id_dim_time
        LEFT JOIN dim_location ON fact_metrics.id_dim_location = dim_location.id_dim_location
ORDER BY 
    year, 
    country_name, 
    sub_region_code
;